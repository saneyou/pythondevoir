#Enonse 10

kod="web-insecure;34829sjdfnsj32984madsdkj"
n=kod.find(";")
i=n + 1
nouvo=kod[i:]
print(nouvo)
