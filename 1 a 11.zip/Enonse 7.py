

a = "I think this is a fucking string"
voyelles = ['a', 'e', 'i', 'o', 'u', 'y']
mot = ""
k = 0
while k < len(a) - 1 :
  if a[k+1] in voyelles:
    mot += "*"
  else:
    mot += a[k]
  k = k + 1
mot += a[len(a) - 1]
print(mot)
