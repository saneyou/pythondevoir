#Enonse 4
from random import randrange

a=2
b=3
div_a=[]
div_b=[]
div_ab=[]
non_ab=[]
t_a=0
t_b=0
t_c=0
t_d=0

for el in range(1,21):
    if el % a == 0:
         div_a.append(el)
    elif el % b == 0:
         div_b.append(el)
    else:
         non_ab.append(el)
div_ab=div_a + div_b


print(div_a,"Total nonb se",len(div_a))
print(div_b,"Total nonb se",len(div_b))
print(div_ab,"total nonb se",len(div_ab))
print(non_ab,"total nonb se",len(non_ab))
      

