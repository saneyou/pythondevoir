#enonse 6
A= "Ayibobo Ayiti"
B=A[::-1]
B= B.replace(" ","")
print(B)
