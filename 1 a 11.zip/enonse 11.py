#Enonse 11
def pi_gran(arr,n):
    max= arr[0]

    for i in range (1,n):
        if arr[i]> max:
            max=arr[i]
    return max

arr=[0, 1, 3, 5, 13, 99, 34, 87, 50]
n=len(arr)
g= pi_gran(arr,n)

def pi_piti(arr,n):
    min= arr [0]

    for i in range (1,n):
        if arr[i]< min:
            min=arr[i]
    return min

p=pi_piti(arr,n)
print("pi gran eleman nan lis la se:",g)
print("Pi piti eleman nan lis la se:",p)
