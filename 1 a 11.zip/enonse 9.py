#Enonse 9
from random import randrange 
a= 1
b=10

m=0
lis=[]

for x in range( b+1):
    if x % 2  == 0:
        m+=x
        lis.append(m)
print(m)

