#1
ip="127.0.0.1"
lis_ip=ip.replace('.','')
total=0

for y in lis_ip:
    total+=int(y)

print(total* int(lis_ip[0]))

#2
antye=16
if antye % 4 == 0:
    a=print("NOKE")
elif antye % 4 != 0:
    a= print('OK')
print(a)

#3
non=input ("Tanpri antre non w: ")
while non== ' ':
    non=input ("Tanpri antre non w: ")
nouvo_non=non.lower()
nouvo_non=nouvo_non.title()
print(nouvo_non)





