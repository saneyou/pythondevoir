# enonse 8

text="I dont give a fuck about this country!"
text=text.replace(" ","")
print(text)
