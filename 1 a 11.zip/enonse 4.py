#enonse 5
chif='5 45 123 12'
x=chif.split()
t=0
m=1
n_lis=[]
m_lis=[]
for i in x:
    a=list(i)
    n_lis.append(a)

    for z in a:
        t+=int(z)
    m_lis.append(t)
    t=0
print(m_lis)
for d in m_lis:
    m*= int(d)
print(m)
    
    
